//S.VISHNU PRANEETH
//14CS30031
#include <C:\c\Date.h>
#include<string.h>
#include<stdlib.h>
#include<exception>
#include<stdexcept>
#include<ctime>
#include<iostream>
using namespace std;

DateFormat::DateFormat(const char* dF,const char* mF,const char* yF)
{
    int var1,var2,var3;
    if(((strcmp(yF,"yyyy")!=0)&&(strcmp(yF,"yy")!=0))||strlen(yF)==0)//throws an error if the year format is not of the form yy/yyyy
    {
        if(((strcmp(yF,"yy")!=0)&&(strcmp(yF,"yyyy")!=0)))
            throw domain_error("given date format doesnt match with yy/yyyy");
        else if(strlen(yF)==0)//if the year format is given to be empty,it is set as empty
            this->yearFormat=strdup("");
        else
            throw domain_error("given date format is of some other format which is nether null/yy/yyyy");
    }
    if((strcmp(mF,"m")!=0&&(strcmp(mF,"mm")!=0)&&(strcmp(mF,"mmm")!= 0))||strlen(mF)==0)//throws an error if the month format is not of the form m/mm/mmm
    {
        if((strcmp(mF,"mmm")!= 0&&(strcmp(mF,"mm")!= 0)&&(strcmp(mF,"m")!= 0)))
            throw domain_error("given date format doesnt match with m/mm/mmm");
        else if(strlen(mF)==0)//if the month format is given t be empty,it is set as empty
            this->monthFormat=strdup("");
        else
            throw domain_error("given date format is of some other format which is neither null/m/mm/mmm");
    }
    if((strcmp(dF,"dd")!=0&&strcmp(dF,"d")!=0)||strlen(dF)==0)//throws an error if the day format is not of the form d/dd
    {
        if((strcmp(dF,"dd")!=0&&strcmp(dF,"d")!=0))
            throw domain_error("given date format doesnt match with d/dd");
        else if(strlen(dF)==0)//if the day format is given to be emoty,it is set as empty
            this->dateFormat=strdup("");
        else
            throw domain_error("given date format is of some other format which is neither null/d/dd");
    }
    if(strlen(yF)!=0)//if the year format is not empty/any other format except yy/yyyy
    {
        var1=strlen(yF)+1;
        delete[] this->yearFormat;
        this->yearFormat = new char[var1];
        strcpy(this->yearFormat, yF);
    }
    if(strlen(mF)!=0)//if the month format is not empty/any other format except m/mm/mmm
    {
        var2=strlen(mF) + 1;
        delete[] this->monthFormat;
        this->monthFormat = new char[var2];
        strcpy(this->monthFormat, mF);
    }
    if(strlen(dF)!=0)//if the day format is not empty/any other format except dd/d
    {
        var3=strlen(dF)+1;
        delete[] this->dateFormat;
        this->dateFormat=new char[var3];
        strcpy(this->dateFormat,dF);
    }


}

DateFormat::DateFormat(const char* format)
{
    int i=0,var5,j,k,l;
    //taking three char* arrays to store the day,month and the year part seperately
    char *dF;
    dF = new char[3];
    char *mF;
    mF = new char[5];
    char *yF;
    yF  = new char[5];
    if(format==NULL)
    {
        throw domain_error("given date format is null which is wrong!!");
    }
    else
    {
    for(;format[i]!='-';i++)
        dF[i] = format[i];//splitting till the first hyphen and storing the day part
    dF[i] = '\0';
    var5=++i;
    for(j=0;format[var5]!='-';++var5,j++)
        mF[j]=format[var5];//splitting till the second hyphen and storing the month part
    mF[j] = '\0';
    k=++var5;
    for(l=0;k<strlen(format);k++,l++)
        yF[l] = format[k];//splitting till the end of the string and storing the year part
    yF[l]='\0';
    cout<<dF<<"-"<<mF<<"-"<<yF<<"\n";//printing the three formats seperated with a hyphen
    (*this)=DateFormat(dF,mF,yF);
    }
}
DateFormat::DateFormat()
{
    delete[] this->yearFormat;
    delete[] this->monthFormat;
    delete[] this->dateFormat;
    //used for setting the default format dd-mmm-yy
    this->yearFormat = new char[strlen("yy")+1];
    this->monthFormat = new char[strlen("mmm")+1];
    this->dateFormat = new char[strlen("dd")+1];
    strcpy(this->dateFormat,"dd");
    strcpy(this->monthFormat,"mmm");
    strcpy(this->yearFormat,"yy");
}
DateFormat::DateFormat(const DateFormat& date)//copy constructor of DateFormat
{
    (*this)=DateFormat(date.dateFormat,date.monthFormat,date.yearFormat);
}
DateFormat& DateFormat::operator=(const DateFormat& date)//overloading operator= for DateFormat
{
    if(this!=&date)//checking for self assignment
    {
        delete[] dateFormat;
        delete[] monthFormat;
        delete[] yearFormat;
        this->dateFormat=new char[strlen(date.dateFormat)];
        strcpy(this->dateFormat,date.dateFormat);
        this->monthFormat=new char[strlen(date.monthFormat)];
        strcpy(this->monthFormat,date.monthFormat);
        this->yearFormat=new char[strlen(date.yearFormat)];
        strcpy(this->yearFormat,date.yearFormat);
    }
    return *this;
}
DateFormat::~DateFormat()//destructor
{
    //deleting yearFormat,monthFormat,dateFormat
    delete[] yearFormat;
    delete[] monthFormat;
    delete[] dateFormat;
}
//3 seperate functions ti return the yearFormat,monthFormat and dateFormat
const char* DateFormat::myyrFormat()
{
    if(yearFormat!=NULL)
        return yearFormat;
    else return NULL;
}
const char* DateFormat::mymthFormat()
{
    if(monthFormat!=NULL)
        return monthFormat;
    else return NULL;
}
const char* DateFormat::mydtFormat()
{
    if(dateFormat!=NULL)
        return dateFormat;
    else return NULL;
}

Date::Date(Day d,Month m,Year y)
{
    if(y > 2049||y < 1950)//checking for out of range error
        throw out_of_range("year is out of range of 2049||1950!!");
    if(!((((y)%4==0)&&((y)%100!=0))||((y)%400==0))&&(m==Feb&&d>28))//if it is not a leap year,february cant have more than 28 days
        throw domain_error("its not possible for february to have more than 28 days in a non leap year!!");
    if(((((y)%4==0)&&((y)%100!=0))||((y)%400==0))&&(d>29&&m==Feb))//if it is a leap year ,february cant have more than 29 days
        throw domain_error("Its not possible for February to have more than 29 days in a leap Year!!");
    if((m==Sep||m==Apr||m==Jun||m==Nov)&&(d>30))//these months cant have more than 30 days
            throw domain_error("Date woth the given month cant have more than 30 days!!");
    if(d>31)//if the no of days in the given date are more than 31,it is an invalid argument
            throw invalid_argument("days exceeded 31!!");
    this->d=d;//if there's no error assign the day,month and the year part
    this->m=m;
    this->y=y;

}
Date::Date(const char* date)
{
    int i,dno=0,mno=0,yno=0,datelength=strlen(Date::format.mydtFormat()),var6,j=0,monthlength=strlen(Date::format.mymthFormat()),k,yrlength= strlen(Date::format.myyrFormat()),l;
    int yearlength=strlen(Date::format.myyrFormat());
    char *dF=new char[strlen(date)+1];//creating three arrays to store the three parts
    char *mF=mF=new char[strlen(date)+1];
    char *yF=new char[strlen(date)+1];
    if(date==NULL)//if the date passed is null,throw domain error
        throw domain_error("Date string given is null");
    if(Date::format.myyrFormat()==NULL||Date::format.mymthFormat()==NULL||Date::format.mydtFormat()==NULL)//if any one of three parts is null,throw domain error
        throw domain_error("one of the formats among day or month or year is null!!");
    for(i=0;date[i]!='-';++i)
        dF[i]=date[i];
    dF[i]='\0';
    for(int v=0;dF[v] != '\0'; ++v)
        dno=dno*10+dF[v]-'0';
    if(dno==0||(datelength==2&&i!=datelength)||(((i!=2&&dno/10!=0)||(i!=1&&dno/10==0))&&datelength==1))//checking different conditions for length of the three seperate arrays and the iteration variable i
    {
        throw domain_error("the given date format is wrong interms of a mismatch or 0 date");
    }
    for(var6=++i,j=0;date[var6]!='-';var6++,j++)
        mF[j]=date[var6];
    mF[j] = '\0';
    int lenmF=strlen(mF);
    if(monthlength==1)//if month is of the form m
    {
        for (int p=0;mF[p] != '\0';p++)
            mno= mno*10+mF[p]-'0';
        if(mno==0||((lenmF != 2)&&(mno/10 > 0)&&(mno/100==0))||(((mno/10 == 0)&&(lenmF!=1)) ))
        {
            throw domain_error("the given date format is wrong interms of a month mismatch or 0 month number");
        }
    }
    else if(monthlength==2)// if month is of the form mm
    {
        for (int p =0;mF[p]!='\0';p++)
            mno=mno*10+mF[p]-'0';
        if(mno==0||(lenmF!=2))
        {
            throw domain_error("the given date format is wrong interms of a month mismatch or 0 month number");
        }
    }
    else if(monthlength==3)//if month is of the form mmm
    {
        if(strcmp(mF,"Jan")==0)
            mno=1;
        else if(strcmp(mF,"Feb")==0)
            mno=2;
        else if(strcmp(mF,"Mar")==0)
            mno=3;
        else if(strcmp(mF,"Apr")==0)
            mno=4;
        else if(strcmp(mF,"May")==0)
            mno=5;
        else if(strcmp(mF,"Jun")==0)
            mno=6;
        else if(strcmp(mF,"Jul")==0)
            mno=7;
        else if(strcmp(mF,"Aug")==0)
            mno=8;
        else if(strcmp(mF,"Sep")==0)
            mno=9;
        else if(strcmp(mF,"Oct")==0)
            mno=10;
        else if(strcmp(mF,"Nov")==0)
            mno=11;
        else if(strcmp(mF,"Dec")==0)
            mno=12;
    }
    for(k=++var6,l=0;k<strlen(date);k++,l++)
        yF[l] = date[k];
    yF[l]='\0';
    //stopped here
    int lenyF=strlen(yF);
    if(yearlength==2)//if the year is of the form yy
    {
        for (int p=0;yF[p]!='\0';p++)
            yno=yno*10+yF[p]-'0';
        if((lenyF != 2)||(yno==0&&strcmp(yF,"00")!= 0))
        {
            throw domain_error("the given date format is wrong interms of a year mismatch or 0 year number");
        }
        if(yno<50)//if the double digit year is lesser than 50,the year is actually within 2000-2049
            yno+=2000;
        else if(yno>=50)//else if the double digit year is greater than or equal to 50,the year is actually within 1950-1999
            yno+=1900;
    }
    else if(yearlength==4)//if the year is of the form yyyy
    {
        for (int p=0;yF[p]!='\0';p++)
            yno=yno*10+yF[p]-'0';
        if(yno==0||lenyF != 4)
        {
            throw domain_error("the given date format is wrong interms of a year mismatch or 0 year number");
        }
    }
    (*this)=Date((Day)dno,(Month)mno,(Year)yno);
}
Date::Date(const Date& date) : Date(date.d, date.m, date.y)//copy constructor for date
{

}
//to return system date..do this later
Date::Date()
{
    time_t now=time(0);
    struct tm * var = localtime(&now);
    (*this)=Date(static_cast<Day>(var->tm_mday),static_cast<Month>(var->tm_mon + 1),static_cast<Year>(var->tm_year+1900));
}

Date::~Date ()
{
}

Date& Date::operator=(const Date& date)
{
    if(this!=&date)//checking self assignment operator
    {
        this->y = date.y;//assign individually
        this->m = date.m;
        this->d = date.d;
        this->format=date.format;//set the format
    }
    return *this;//return obj
}

Date& Date::operator++()
{
    if(m==Dec)//if the month is december
    {
        if((int)(this->d)+1<=31)//and the day+1 in the month lies between 1st and <=31st december normally increment just the day
             this->d=(Day)((this->d) + 1);
        else//if day+1 is exceeding 31st december
        {
            if((y+1)>2049)//and if the year also exceeded 2049 after the incrementing process
                throw out_of_range("date obtained after adding 1 is exceeding 2049!!");
            else//increment the year as it is a new year
                this->y=(Year)((this->y) + 1);
            this->m=Jan;//th month gets incremented to january
            this->d=D01;//the day is obviously incremented to the next day which is the first day of the new year(next year)
        }
    }
    else if(m==Jan||m==Mar||m==May||m==Jul||m==Aug||m==Oct)//if the month contains 31 days
    {
        if((this->d+1)>0&&(this->d+1)<=31)//if the day+1 in the given date is not on the boundary and less than or equal to 31 of that month
            this->d=(Day)((this->d)+1);//just normally increment the day
        else//if the day+1 is greater than 31
        {
            this->d=D01;//make the day as the first day of the next month
            this->m=(Month)((this->m)+1);//month is ti be incremented
        }
    }
    else if(m==Feb)//if the month is a february
    {
        if(!(this->leapYear()))//and is not a leap year
        {
            if((this->d+1>0)&&(this->d+1<=28))//if day+1 is a normal day of february less than  or equal to 28
                (this->d)=(Day)((this->d)+1);//just normally increment the day
            else//the day+1 is greater than 28
            {
                this->d=D01;//the day+1 is to be set to the first day of the next month (march)
                this->m=Mar;//(Month)((this->m)+1);//the month is set to the next month(March)
            }
        }
        else if(this->leapYear())//is a leap year
        {
            if((this->d+1)>0&&(this->d+1)<=29)//if day+1 is a normal day of february less than or equal to 29 as in a leap year
                this->d=(Day)((this->d)+1);//just normally increment the day
            else//the day+1 is greater than 29
            {
                this->d=D01;//the day+1 is to be set to the first day of the next month(march)
                this->m=Mar;//the month is set to be the next month March
            }
        }
    }
    else if(m==Apr||m==Jun||m==Sep||m==Nov)//if the month is any of the the 30 days months
    {
        if((this->d+1)>0&&(this->d+1)<=30)//and the day is a normal day which is less than pr equal to 30
            this->d=(Day)((this->d)+1);//the day is normally incremented
        else
        {
            this->d=D01;//the day+1 is set to be the first day of the next month
            this->m=(Month)((this->m)+1);//the month is normally incremented to be the next month
        }
    }
    return *this;//return the obj
}

Date& Date::operator++(int x)
{
    int i=0;
    Date& temp=*this;//store the object in a temp obj
    while(i<7)//in this the same day of the next week is to be returned..this is done by using operator++() for 7 times to increment by 1 week
    {
        ++(temp);//increment the temp obj by calling the operator++() function
        i++;
    }
    return temp;//return the temp object
}

Date& Date::operator--()
{
    //similar to that of operator++() but decrement at each time.
    if(m==Jan)//for january,there's a special case for 1st Jan as decrementing wud take it to the previous year's december 31st
    {
        if((this->d-1)>0)
            this->d = (Day)((this->d) - 1);//just normally decrement the day
        else
        {
            if((this->y-1)>=1950&&(this->y-1)<2049)
            {
                this->d=D31;//day is to be assigned to last day of December
                this->m=Dec;//month is to be assigned to December
                //cout<<"year"<<y<<endl;
                this->y=(Year)((this->y) - 1);
            }
            else//the year-1 goes less than 1950
                throw out_of_range("the date obtained after decrementing is going less than 1950!!");
        }
    }
    else if(m==Apr||m==Jun||m==Aug||m==Sep||m==Nov||m==Feb)//if the month is of 30 days
    {
        if((this->d-1)>0)
            this->d=(Day)((this->d)-1);//just decement the day
        else
        {
            this->d=D31;// set the day to 31st of the before month
            this->m=(Month)((this->m)-1);//the month is set to the previous month
        }
    }
    else if(m==Mar)//for the 1st day of march.there exists a special case when its a leap year
    {
        if(!(this->leapYear()))//not a leap year
        {
            if((this->d-1)>0)//day-1 is a normal day
                this->d=(Day)((this->d)-1);//day is decremented normally
            else
            {
                this->d=D28;//day is set to 28th of february
                this->m=Feb;//month is set to february
            }
        }
        else if(this->leapYear())//if the year is leap year
        {
            if((this->d-1)<=0)//if the day-1 is<=0
            {
                this->d=D29;//the day is set to 29th february
                this->m=Feb;//the month is set to february
            }
            else
                this->d=(Day)((this->d)-1);//the day is normally decremented
        }
    }
    else if(m==May||m==Jul||m==Oct||m==Dec)//31 days months
    {
        if((this->d-1)>0)
            this->d=(Day)((this->d)-1);//just decrement the day normally
        else
        {
            this->m=(Month)((this->m)-1);//the month is normally decremented
            this->d=D30;//the day is set to 30th of the previous month
        }
    }
    return *this;//return obj
}

Date& Date::operator--(int x)
{
    int j=0;
    Date& temp=*this;//temp obj to store the obj
    while(j<7)//keep decrementing till a week using operator--()
    {
        --(temp);
        j++;
    }
    return temp;//return temp obj
}

unsigned int Date::operator-(const Date& otherDate) const
{
    int dcount=0;
    Date presdate(*this);
    if(presdate==otherDate)//if both are equal the difference is equal to 0
        dcount=0;
    else if(presdate>otherDate)//if the present date is greater than the other date
    {
        while(presdate!=otherDate)//until the present date is not equal to the other date
        {
            ++dcount;//keep counting the number of days
            --presdate;//keep decrementing the present date
        }
    }
    else//the present date is less than the other date
    {
        while(presdate!=otherDate)//until the present date is not equal to the other date
        {
            ++dcount;//keep counting the days
            ++presdate;//keep incrementing the present date
        }
    }
    return dcount;//return the number of days counted
}

Date Date::operator+(int noOfDays) const
{
    Date vardate(*this);

    for(int k=0;k<noOfDays;k++)//till the required number of days
            ++vardate;//keep incrementing the present date
    if(noOfDays<0)//if the no of days is negative.
    {
        for(int l=noOfDays;l<0;l++)//till the number of days
            --vardate;//keep decrementing the present date
    }
    return vardate;//return the modified date
}
Date::operator WeekNumber() const
{
    Date yearinitdt=Date(D01,Jan,this->y);
    Date temp=Date(D01,Jan,(this->y)+1);
    WeekDay tempday=(WeekDay)temp;
    WeekDay strday=(WeekDay)yearinitdt;
    int moncount=0;
    int thrcount1=0;
    while(tempday!=Thr)
    {
        thrcount1++;
        tempday=(WeekDay)((static_cast<unsigned int>(tempday))%7+1);
    }
    Date firstthrday=temp+thrcount1;
    Date monday=firstthrday+(-3);
    if(monday<(*this))
        return W01;

    else
    {
    int thrcount=0;
    while(strday!=Thr)
    {
        thrcount++;
        strday=(WeekDay)((static_cast<unsigned int>(strday))%7+1);
    }
    int strofweek=thrcount-3;
    yearinitdt=yearinitdt+(strofweek);
    if(*this<(yearinitdt))
        return W53;
    return (WeekNumber)(((int)((*this-yearinitdt)/7)+1)%54);
    }
}

Date::operator Month() const
{
    return this->m;//return the month of the date
}

Date::operator WeekDay() const
{
    int y1=this->y;
    int m1=this->m;
    static int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
    y1-=m1< 3;
    if((y1 + y1/4 - y1/100 + y1/400 + t[m1-1] + this->d) % 7 != 0)
        return (WeekDay)((static_cast<unsigned int>(y1 + y1/4 - y1/100 + y1/400 + t[m1-1] + this->d)) % 7);
    else
    return Sun;
}

bool Date::leapYear() const
{
    //general leap year conditions
     if((((this->y)%4==0)&&((this->y)%100!=0))||((this->y)%400==0))
        return true;
    else
        return false;
}
bool Date::operator==(const Date& otherDate) const
{
    //for two dates to be equal all the three parts
    if((this->y==otherDate.y)&&(this->m==otherDate.m)&&(this->d==otherDate.d))
        return true;
    else return false;
}
bool Date::operator!=(const Date& otherDate) const
{
    if((this->y!=otherDate.y)||(this->m!=otherDate.m)||(this->d!=otherDate.d))//if any one of the three parts is not equal ,then dates are not equal
            return true;
    else return false;
}
bool Date::operator<(const Date& otherDate) const
{//checking conditions accordingly for date1<date2
    if((this->y)==(otherDate.y)&&(this->m<otherDate.m))
        return true;
    else if((this->y)==(otherDate.y)&&(this->m > otherDate.m))
        return false;
    else if((this->y)==(otherDate.y)&&(this->m==otherDate.m))
    {
        if(this->d<otherDate.d)
            return true;
        else
            return false;
    }
    else if((this->y)>(otherDate.y))
        return false;
    else if((this->y)<(otherDate.y))
        return true;
}
bool Date::operator<=(const Date& otherDate) const
{
    //checking conditions accordingly for date1<=date2
    if(this->y==otherDate.y&&this->m < otherDate.m)
            return true;

    else if((this->y==otherDate.y)&&(this->m > otherDate.m))
            return false;
    else if((this->y==otherDate.y)&&(this->m==otherDate.m))
    {
            if(this->d < otherDate.d)
                return true;
            else if(this->d==otherDate.d)
                return true;
            else
                return false;
    }
    else if(this->y>otherDate.y)
        return false;
    else if(this->y<otherDate.y)
        return true;
}

bool Date::operator>(const Date& otherDate) const
{
    //checking conditions accordingly for date1>date2
    if(this->y==otherDate.y&&this->m>otherDate.m)
            return true;
    else if(this->y==otherDate.y&&this->m<otherDate.m)
            return false;
    else if(this->y==otherDate.y&&this->m==otherDate.m)
    {
        if(this->d>otherDate.d)
            return true;
        else
            return false;
    }
    else if(this->y>otherDate.y)
        return true;
    else if(this->y<otherDate.y)
        return false;
}

bool Date::operator>=(const Date& otherDate) const
{
    ////checking conditions accordingly for date1>=date2
    if(this->y==otherDate.y&&this->m>otherDate.m)
        return true;
    else if(this->y ==otherDate.y&&this->m<otherDate.m)
        return false;
    else if(this->y==otherDate.y&&this->m==otherDate.m)
    {
        if(this->d > otherDate.d)
            return true;
        else if(this->d==otherDate.d)
            return true;
        else
            return false;
    }
    else if(this->y>otherDate.y)
        return true;
    else if(this->y < otherDate.y)
        return false;
}
ostream& operator<<(ostream& out,const Date& date)
{
    if(strlen(Date::format.mydtFormat())!=0)
    {
        if(strlen(Date::format.mydtFormat())==1)
            out<<(int)date.d<<"-";
        else if((strlen(Date::format.mydtFormat())==2)&&((int)date.d/10 == 0))
            out<<"0"<<(int)date.d<<"-";
        else if((strlen(Date::format.mydtFormat())==2)&&((int)date.d/10 != 0))
            out<<(int)date.d<<"-";
    }
    if(strlen(Date::format.mymthFormat())==0)
    {
        if(date.m==Jan)
            out<<"January-";
        else if(date.m==Feb)
            out<<"February-";
        else if(date.m==Mar)
            out<<"March-";
        else if(date.m==Apr)
            out<<"April-";
        else if(date.m==May)
            out<<"May-";
        else if(date.m==Jun)
            out<<"June-";
        else if(date.m==Jul)
            out<<"July-";
        else if(date.m==Aug)
            out<<"August-";
        else if(date.m==Sep)
            out<<"September-";
        else if(date.m==Oct)
            out<<"October-";
        else if(date.m==Nov)
            out<<"November-";
        else if(date.m==Dec)
            out<<"December-";

    }
    else if(strlen(Date::format.mymthFormat())!=0)
    {
        if(strlen(Date::format.mymthFormat())==1)
            out<<(int)date.m<<"-";
        else if( strlen(Date::format.mymthFormat())==2&&(((int)date.m/10)==0))
                out<<"0"<<(int)date.m<<"-";
        else if( strlen(Date::format.mymthFormat())==2&&((int)date.m/10!=0))
                out<<(int)date.m<<"-";
        else if(strlen(Date::format.mymthFormat())==3)
        {
            if((date.m)==Jan)
                out<<"Jan-";
            else if((date.m)==Feb)
                out<<"Feb-";
            else if((date.m)==Mar)
                out<<"Mar-";
            else if((date.m)==Apr)
                out<<"Apr-";
            else if((date.m)==May)
                out<<"May-";
            else if((date.m)==Jun)
                out<<"Jun-";
            else if((date.m)==Jul)
                out<<"Jul-";
            else if((date.m)==Aug)
                out<<"Aug-";
            else if((date.m)==Sep)
                out<<"Sep-";
            else if((date.m)==Oct)
                out<<"Oct-";
            else if((date.m)==Nov)
                out<<"Nov-";
            else if((date.m)==Dec)
                out<<"Dec-";
            }
    }
    if(strlen(Date::format.myyrFormat())!=0)
    {
        if(strlen(Date::format.myyrFormat())==2)
        {
            if((int)(date.y%100)/10==0)
                out<<"0"<<(int)(date.y%100);
            else
                 out<<(int)(date.y%100);
        }
        else if(strlen(Date::format.myyrFormat())==4)
            out<<date.y;
    }
    return out;
}

istream& operator>>(istream& in, Date& date)
{
    char *newstring=new char[12];
    in>>newstring;
    date=Date(newstring);
    return in;
}

void Date::setFormat(const DateFormat& fmt)
{
       Date::format = (fmt);
}

DateFormat& Date::getFormat()
{
    return Date::format;
}
