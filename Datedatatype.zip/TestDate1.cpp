//S.VISHNU PRANEETH
//14CS30031
#include <C:\c\Date.cpp>
#include<exception>
using namespace std;
DateFormat Date::format;

void TestDate1()
{
    try
    {
        cout<<"Setting default date format (dd-mmm-yy)"<<endl;
        cout<<Date::getFormat().mydtFormat()<<"-"<<Date::getFormat().mymthFormat()<<"-"<<Date::getFormat().myyrFormat()<<endl;
        Date d1(D22,Apr,2016);
        cout<<"New date created by calling Date(Day d, Month m, Year y)"<<endl;
        cout<<"New date d1="<<d1<<endl;
       try
        {
            //here year as 00 will be taken as 2000
            Date d2("12-Feb-00");//no probs
            cout<<"Initialising d2 by calling Date(const char* date) constructor"<<endl;
            cout<<"d2="<<d2<<endl;
            cout<<"Setting date d3 as an invalid date 00-Feb-13"<<endl;
            Date d3("00-Feb-13");
        }
        catch(domain_error& e)
        {
            cout<<"calling DateFormat(const char* format)..."<<e.what()<<'\n';
        }
        try
        {
            cout<<"Changing format to..."<<endl;
            cout<<"ddd-m-yy"<<endl;
            Date::setFormat(DateFormat("ddd-m-yy"));
            cout<<Date::getFormat().mydtFormat()<<"-"<<Date::getFormat().mymthFormat()<<"-"<<Date::getFormat().myyrFormat()<<endl;
        }
        catch(domain_error& e)
        {
            cout<<"invalid format:"<<e.what()<<endl;//everytime this prints an exception in month...even if date is of the from ddd...
        }

        cout<<"Changing Format to..."<<endl;
        DateFormat df = DateFormat("dd-mm-yy");
        Date::setFormat(df);
        cout<<Date::getFormat().mydtFormat()<<"-"<<Date::getFormat().mymthFormat()<<"-"<<Date::getFormat().myyrFormat()<<" "<<endl;


        try
        {
            cout<<"Setting d3 as an invalid date 283-10-16"<<endl;
            Date d3("283-10-16");
        }
        catch(domain_error& e)
        {
            cout<<"invalid value:"<<e.what()<<endl;
            //cout<<Date::getFormat().mydtFormat()<<"-"<<Date::getFormat().mymthFormat()<<"-"<<Date::getFormat().myyrFormat()<<endl;
        }
        try
        {
        DateFormat df1=DateFormat("-mm-yyyy");
        Date::setFormat(df1);
        cout<<Date::getFormat().mydtFormat()<<"-"<<Date::getFormat().mymthFormat()<<"-"<<Date::getFormat().myyrFormat()<<endl;
        }
        catch(domain_error& e)
        {
            cout<<"invalid format:"<<e.what()<<endl;
        }
        try
        {
        Date d6("-01-1996");
        }
        catch(domain_error& e)
        {
            cout<<e.what()<<endl;
        }
        try{
        Date::setFormat(DateFormat("-mm-"));
        cout<<Date::getFormat().mydtFormat()<<"-"<<Date::getFormat().mymthFormat()<<"-"<<Date::getFormat().myyrFormat()<<endl;
        }
        catch(domain_error& e)
        {
            cout<<"invalid format:"<<e.what()<<endl;
        }
        try
        {
        Date d7("-09-");
        }
        catch(domain_error& e)
        {
            cout<<e.what()<<endl;
        }
        try{
        DateFormat df2=DateFormat("dd--yy");
        Date::setFormat(df2);
        }
        catch(domain_error& e)
        {
            cout<<"invalid format:"<<e.what()<<endl;
        }

        cout<<Date::getFormat().mydtFormat()<<"-"<<Date::getFormat().mymthFormat()<<"-"<<Date::getFormat().myyrFormat()<<endl;
        Date d4("11-12-16");
        Date d5;
        cout<<d5<<endl;
        Date d6(d5);
        cout<<"This is an initialised date:d4="<<d4<<endl;
        cout<<"Calling default constructor...initialising d5 to system date:"<<d5<<endl;
        cout<<"After copying d5 into d6 via the copy constructor d6:"<<d6<<endl;
        d5=d4;//checking assignment
        cout<<"Checking assignment operator...d5 becomes equal to d1:"<<d5<<endl;
        //pre increment operator
        cout<<endl<<"Checking operator++()"<<endl<<endl;
        ++d5;
        cout<<"This is checking pre increment operator for a normal date:d5++="<<d5<<endl;

        d5=Date("30-09-30");//30 days month ending
        cout<<"Changing...d5="<<d5<<endl;
        ++d5;
        cout<<"This is a special case for checking increment at the end of a 30 days month.So after incrementing d5="<<d5<<endl;
        //print the value of copycat

        d5=Date("31-10-30");//31 days month ending
        cout<<"Changing...d5="<<d5<<endl;
        ++d5;
        cout<<"This is a special case for checking increment at the end of a 31 days month.So after incrementing d5="<<d5<<endl;

        d5=Date("29-02-16");//leap year ending
        cout<<"Changing...d5="<<d5<<endl;
        ++d5;
        cout<<"This is a special case for checking increment at the end of a february in a leap year.So after incrementing d5="<<d5<<endl;

        d5=Date("28-02-15");
        cout<<"Changing...d5="<<d5<<endl;
        ++d5;
        cout<<"This is a special case for checking increment at the end of a february in a non leap year.So after incrementing d5="<<d5<<endl;

        cout<<endl<<"/*Just checking if it accepts wrong date inputs of a february month..."<<endl;
        try
        {
        d5=Date("29-02-15");//just acheck if it accepts 29 th day in february for a non leap year
        }
        catch(domain_error& e)
        {
            cout<<e.what()<<endl;
        }
        cout<<"*/"<<endl;
        cout<<"So d5 isnt changed...d5="<<d5<<endl;
        try
        {
            d5=Date("31-12-49");
            cout<<"Changing...d5="<<d5<<endl;
            cout<<"Incrementing..."<<endl;
            ++d5;
        }//checking for a new year
        catch(out_of_range& e)
        {
            cout<<"going out of 2049!!"<<e.what()<<endl;
        }
        cout<<"So d5 isnt changed...d5="<<d5<<endl;
        Date::setFormat("dd-mmm-yy");
        Date d7("23-Oct-16");
        cout<<endl<<"Checking operator++(int x)"<<endl<<endl;
        cout<<"Initialising d7...d7="<<d7<<endl;
        cout<<"Incrementing..."<<endl;
        d7++;
        cout<<"This is checking increment operator which returns the same day of the next week of a normal day...So after incrementing d7="<<d7<<endl;
        try{
        d7=Date("31-Dec-49");
        cout<<"Changing...d7="<<d7<<endl;
        cout<<"Incrementing..."<<endl;
        d7++;
        cout<<"This is checking increment operator which returns the same day of the next week of a 31st december 2049...So after incrementing d7="<<d7<<endl;
        }
        catch(out_of_range& e)
        {
            cout<<"going out of 2049!!"<<e.what()<<endl;
        }
        cout<<"Since incrementing d7 results in an error,d7 is not incremented...d7="<<d7<<endl;
        d7=Date("29-Feb-12");
        cout<<"Changing...d7="<<d7<<endl;
        cout<<"Incrementing..."<<endl;
        d7++;
        cout<<"This is checking increment operator which returns the same day of the next week at the end of february in a leap year...So after incrementing d7="<<d7<<endl;
        cout<<d7<<endl;

        cout<<endl<<"Checking operator--()"<<endl<<endl;
        Date d8("18-Mar-21");
        cout<<"Initialising d8...d8="<<d8<<endl;
        cout<<"Decrementing ..."<<endl;
        --d8;
        cout<<"This is checking decrement operator for a normal day of the year...So after decrementing d8="<<d8<<endl;
        d8=Date("01-Mar-16");
        cout<<"Changing...d8="<<d8<<endl;
        cout<<"Decrementing ..."<<endl;
        --d8;
        cout<<"This is checking decrement operator for the day just after last day of february 2016(leap year)...So after decrementing d8="<<d8<<endl;
        d8=Date("01-Jan-50");
        cout<<"Changing...d8="<<d8<<endl;
        try{
            cout<<"Decrementing ..."<<endl;
            --d8;
        }
        catch(out_of_range& e)
        {
            cout<<"After decrementing the date goes less than 1950 which is not valid"<<e.what()<<endl;
        }
        cout<<"Since this is an error...d8 isnt changed d8="<<d8<<endl;
        cout<<"Changing date format..."<<endl;
        Date::setFormat("d-mmm-yy");


        Date d9=Date("6-Dec-14");
        cout<<endl<<"Checking operator--(int)"<<endl<<endl;
        cout<<"Initialising d9...d9="<<d9<<endl;
        cout<<"Decrementing..."<<endl;
        d9--;
        cout<<"This is checking decrement operator which returns the same day in the previous week for a normal day in the year...So after decrementing d9="<<d9<<endl;
        d9=Date("6-Jan-50");
        try{
        cout<<"Changing...d9="<<d9<<endl;
        cout<<"Decrementing..."<<endl;
        d9--;
        }
        catch(out_of_range& e)
        {
            cout<<"After decrementing the date goes less than 1950 which is not valid:"<<e.what()<<endl;
        }
        cout<<"Since it is an error d9 isnt changing..So d9="<<d9<<endl;

        cout<<endl<<"Checking unsigned int operator-(const Date& otherDate)"<<endl<<endl;
        d9=Date("22-Apr-12");
        cout<<"Changing...d9="<<d9<<endl;
        Date d2=Date("22-Apr-09");
        cout<<"Initialising...d2="<<d2<<endl;
        cout<<"Returning the number of days between d2 and d9:d9-d2="<<(d9-d2)<<endl;
        cout<<endl<<"Checking operator+(int noOfDays)"<<endl<<endl;
        try{
        cout<<"adding positive number of days to d2"<<endl;
        d9=d2+1234567;
        }
        catch(out_of_range& e)
        {
            cout<<"After adding the number the date goes beyond 2049."<<e.what()<<endl;
        }
        cout<<"Since incrementing resulted in an error d9 isnt changed.d9="<<d9<<endl;
        try{
        cout<<"adding negative number of days to d2"<<endl;
        d9=d2+(-1234567);
        }
        catch(out_of_range& e)
        {
            cout<<"After decrementing the number the date goes less than 1950."<<e.what()<<endl;
        }
        cout<<"Since decrementing resulted in an error d9 isnt changed.d9="<<d9<<endl;
        d9=d2+(-12);
        cout<<"After adding a negative number to d9.d9="<<d9<<endl;
        cout<<"Changing date format..."<<endl;
        Date::setFormat(DateFormat("dd-mmm-yyyy"));
        cout<<"New Format:";
        cout<<Date::getFormat().mydtFormat()<<"-"<<Date::getFormat().mymthFormat()<<"-"<<Date::getFormat().myyrFormat()<<endl;
        cout<<endl<<"Checking operator WeekNumber() const"<<endl<<endl;
        Date d10=Date("31-Dec-2013");
        cout<<"Initialising d10="<<d10<<endl;
        cout<<"WeekNumber of d10="<<WeekNumber(d10)<<endl;//some shit happening here..PLS CHECK!!
        cout<<endl<<"Checking operator Month() const"<<endl<<endl;
        cout<<"Month of d10="<<Month(d10)<<endl;
        cout<<endl<<"Checking operator WeekDay() const"<<endl<<endl;
        cout<<"WeekDay of d10="<<WeekDay(d10)<<endl;
        d10=Date("01-Jan-2016");
        cout<<"Changing d10..."<<endl;
        cout<<"d10="<<d10<<endl;
        cout<<"WeekNumber of d10="<<WeekNumber(d10)<<endl;//some shit happening here..PLS CHECK!!
        cout<<endl<<"Checking operator Month() const"<<endl<<endl;
        cout<<"Month of d10="<<Month(d10)<<endl;
        cout<<endl<<"Checking operator WeekDay() const"<<endl<<endl;
        cout<<"WeekDay of d10="<<WeekDay(d10)<<endl;
        d10=Date("01-Jan-2014");
        cout<<"Changing d10..."<<endl;
        cout<<"d10="<<d10<<endl;
        cout<<"WeekNumber of d10="<<WeekNumber(d10)<<endl;//some shit happening here..PLS CHECK!!
        cout<<endl<<"Checking operator Month() const"<<endl<<endl;
        cout<<"Month of d10="<<Month(d10)<<endl;
        cout<<endl<<"Checking operator WeekDay() const"<<endl<<endl;
        cout<<"WeekDay of d10="<<WeekDay(d10)<<endl;
        d10=Date("01-Jan-2048");
        cout<<"Changing d10..."<<endl;
        cout<<"d10="<<d10<<endl;
        cout<<"WeekNumber of d10="<<WeekNumber(d10)<<endl;//some shit happening here..PLS CHECK!!
        cout<<endl<<"Checking operator Month() const"<<endl<<endl;
        cout<<"Month of d10="<<Month(d10)<<endl;
        cout<<endl<<"Checking operator WeekDay() const"<<endl<<endl;
        cout<<"WeekDay of d10="<<WeekDay(d10)<<endl;

        cout<<endl<<"Checking bool leapYear() const"<<endl<<endl;
        cout<<"The value returned is 1 if a date is leap Year else 0 if the year is not a leap year.The value returned for d10="<<d10<<"is "<<d10.leapYear()<<endl;
        Date d11=Date("01-Jan-2016");
        cout<<"Initialising d11="<<d11<<endl;
        cout<<endl<<"Checking bool operator==(const Date& otherDate)"<<endl<<endl;
        cout<<"The value is 1 if both d10 and d11 are equal else 0,value returned is "<<(d10==d11)<<endl;
        cout<<"The value is 1 if both d9 and d11 are equal else 0,value returned is "<<(d9==d11)<<endl;
        cout<<endl<<"Checking bool operator!=(const Date& otherDate)"<<endl<<endl;
        cout<<"The value returned is 1 if both d9 and d11 are not equal,else 0 if they are equal,value returned is "<<(d9!=d11)<<endl;
        cout<<"The value returned is 1 if both d10 and d11 are not equal,else 0 if they are equal,value returned is "<<(d10!=d11)<<endl;
        cout<<endl<<"Checking bool operator<(const Date& otherDate)"<<endl<<endl;
        cout<<"The value returned is 1 if d9<d11,else 0,the value returned is "<<(d9<d11)<<endl;
        cout<<"The value returned is 1 if d10<d11,else 0,the value returned is "<<(d10<d11)<<endl;
        cout<<endl<<"Checking bool operator<=(const Date& otherDate)"<<endl<<endl;
        cout<<"The value returned is 1 if d10<=d11,else 0,the value returned is "<<(d10<=d11)<<endl;
        cout<<"The value returned is 1 if d11<=d9,else 0,the value returned is "<<(d11<=d9)<<endl;
        cout<<endl<<"Checking bool operator>(const Date& otherDate)"<<endl<<endl;
        cout<<"The value returned is 1 if d10>d11,else 0,the value returned is "<<(d10>d11)<<endl;
        cout<<"The value returned is 1 if d11>d9,else 0,the value returned is "<<(d11>d9)<<endl;
        cout<<endl<<"Checking bool operator>=(const Date& otherDate)"<<endl<<endl;
        cout<<"The value returned is 1 if d9>=d11,else 0,the value returned is "<<(d9>=d11)<<endl;
        cout<<"The value returned is 1 if d11>=d9,else 0,the value returned is "<<(d11>=d9)<<endl;
    }
    catch(invalid_argument& e)
    {
        cout<<"invalid argument error!!"<<e.what()<<endl;
    }
    catch(domain_error& e)
    {
        cout<<"domain error!!"<<e.what()<<endl;
    }
    catch(out_of_range& e)
    {
        cout<<"out of range error!!"<<e.what()<<endl;
    }
    catch(exception e)
    {
        cout<<"some random error "<<endl;
    }
}

int main()
{
    TestDate1();
}
